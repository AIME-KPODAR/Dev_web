# Gooey Menu

A Pen created on CodePen.

Original URL: [https://codepen.io/lbebber/pen/LELBEo](https://codepen.io/lbebber/pen/LELBEo).

Gooey menu with CSS and SVG filters. Version 1