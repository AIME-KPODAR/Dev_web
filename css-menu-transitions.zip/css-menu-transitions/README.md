# CSS menu transitions

A Pen created on CodePen.

Original URL: [https://codepen.io/Khaosmuhaha/pen/azwPwZ](https://codepen.io/Khaosmuhaha/pen/azwPwZ).

A collection of some menu effects, to inspire ye all! I don't recommend using these though, as these are not very responsive or efficient. But use them to get inspired! Only tested on Firefox 35.0, so might glitch out on other browsers. x(