# CSS wavy animation

A Pen created on CodePen.

Original URL: [https://codepen.io/porsake/pen/JjydjLz](https://codepen.io/porsake/pen/JjydjLz).

