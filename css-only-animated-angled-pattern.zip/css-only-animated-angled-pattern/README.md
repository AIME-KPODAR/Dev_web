# CSS only animated angled pattern

A Pen created on CodePen.

Original URL: [https://codepen.io/t_afif/pen/xxaOXQr](https://codepen.io/t_afif/pen/xxaOXQr).

Animated version of: https://codepen.io/t_afif/pen/MWqyNzx